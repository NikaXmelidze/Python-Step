



string = input("Enter sentence: ")

if "small" in string:
    if "tall" in string:
        if "middle" in string:
            print("small")
elif "tall" in string:
    if "small" in string:
        if "middle" in string:
            print("tall")
elif "middle" in string:
    if "small" in string:
        if "tall" in string:
            print("middle")
else:
    print("None of the 3 words ar in the sentence")



