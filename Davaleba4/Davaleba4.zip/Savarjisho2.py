

text = input("Enter text: ")

textLength = len(text)

for i in range(textLength):

    print(ord(text[i]), end=" ")

