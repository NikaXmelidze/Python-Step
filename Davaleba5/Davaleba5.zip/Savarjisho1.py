

mylist = [36, 73, 1, 7, 54, 100, 237, 34, 76, 10, 7, 9 , 12, 34, 49]

sum = mylist[2] + mylist[8] + mylist[13]

print(mylist[2])
print(mylist[8])
print(mylist[13])
print(sum)