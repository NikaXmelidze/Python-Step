

total_sum = 0


while True:
    numberAsString = input("Enter number: ")
    if numberAsString == "sum":
        print(total_sum)
        break
    else:
        number = int(numberAsString)
        total_sum = total_sum + number