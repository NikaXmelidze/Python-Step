

number = int(input("Enter number: "))

while number > 0:
    if number == 1:
        print(number)
        number = number - 1
    else:
        print(number, end=", ")
        number = number - 1

