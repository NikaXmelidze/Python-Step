

list1 = [1,2,3,4,5,6,7]


oddList = filter(lambda a : a%2 != 0, list1) 

print(list(oddList))
